export enum EndPoints {
  CREATE_BOOKING_ENDPOINT = "/booking",
  GET_BOOKING_ENDPOINT = "/booking",
  GET_USER_TOKEN = "/auth",
  UPDATE_BOOKING_ENDPOINT = "/booking",
}
