export enum SuiteTags {
  BOOKING = "@booking",
  AUTH = "@auth",
  CREATE_BOOKING = "@create @booking",
  UPDATE_BOOKING = "@update @booking",
}
