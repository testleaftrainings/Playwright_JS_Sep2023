export enum AppNameConstants {
  SALES_APP = 'Sales',
}
