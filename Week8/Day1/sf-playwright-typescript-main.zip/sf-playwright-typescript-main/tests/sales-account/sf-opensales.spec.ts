import { LoginPage } from "../../page-objects/loginPage";
import { FrameWorkHelper } from "../../utils/frameworkHelper";
import { EnvConstants } from "../../constants/envConstants";
import { URLConstants } from "../../constants/urlConstants";
import { SetupHomePage } from "../../page-objects/setupHomePage";
import { loggedInTests } from "../fixtures";
import { SalesHomePage } from "../../page-objects/salesHomePage";
import { FeatureTags } from "../../constants/featureTags";
import { TestPriorityTags } from "../../constants/testPriorityTags";

loggedInTests.describe(`${FeatureTags.ACCOUNT_CREATION}`, async () => {
  loggedInTests(
    `${TestPriorityTags.P0} TC001: verify user after login is able to open sales application`,
    async ({ loggedInPage }) => {
      const appData = FrameWorkHelper.loadTestData(EnvConstants.STAGE);
      const homePage = new SetupHomePage(loggedInPage);
      await homePage.loadThePage();
      await homePage.verifyThePageIsLoaded();
      await homePage.navBarComponent.clickOnAppLauncherIcon();
      await homePage.navBarComponent.appLauncherComponent.clickOnViewAllButton();
      const salesHomePage =
        await homePage.navBarComponent.appLauncherComponent.clickOnSalesTilesInExapndedAppLauncher();
      await salesHomePage.openAccountsTab();
      await salesHomePage.verifyThePageIsLoaded();
    }
  );
});
