import { test as base} from '@playwright/test';
import { AppData, FrameWorkHelper } from '../utils/frameworkHelper';
import { EnvConstants } from '../constants/envConstants';
import { LoginPage } from '../page-objects/loginPage';
import { HomePage } from '../page-objects/homePage';


type CreateAccountPages = {
    homePage:HomePage
    loginPage:LoginPage
}



export const createAccountTests = base.extend<{
    createAccountPage:CreateAccountPages
}>({
    
    createAccountPage: async({page},use)=>{
        //creation all the required page instances before starting the test
        const loginPage = new LoginPage(page)
        const homePage = new HomePage(page)
        await use({
            homePage:homePage,
            loginPage:loginPage
        })
    }
    
})



export const loggedInTests = base.extend<{
    appTestData:AppData
}>({

    //only call basis
    appTestData: async ({},use) =>{
        //setup part
        const appTestData = FrameWorkHelper.loadTestData(EnvConstants.STAGE)
        //consumer part
        await use(appTestData)
        //tear down
    },

    context:async({browser},use)=>{
        const newContext = await browser.newContext({
            storageState:""
        })
    },

  });

  export const nonLoggedInTests = base.extend<{
    appTestData:AppData
}>({

    appTestData: async ({},use) =>{
        //setup part
        const appTestData = FrameWorkHelper.loadTestData(EnvConstants.STAGE)
        //consumer part
        await use(appTestData)
        //tear down
    },

  });