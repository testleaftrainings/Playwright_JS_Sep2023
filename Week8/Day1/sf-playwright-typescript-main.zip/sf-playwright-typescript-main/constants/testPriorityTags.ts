export enum TestPriorityTags {
  P0 = "@P0",
  P1 = "@P1",
  P2 = "@P2",
}
