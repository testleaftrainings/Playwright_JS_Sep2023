//enum

export enum AppConstants{
    INSTANCE_URL = "https://qeagle-dev-ed.lightning.force.com/lightning/setup/SetupOneHome/home",
}


export enum ToggleStates{
    ON = "ON",
    OFF = "OFF"
}