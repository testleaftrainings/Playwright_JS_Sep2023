import { Locator } from "@playwright/test";

export type LocateBy = Locator| string

export interface IPageAction{
    
    //abstract method
    clickOn(locateBy:LocateBy,stepTitle:string):Promise<void>;

    fillIn(locateBy:Locator|string,textToFill:string):Promise<void>

    isLocatorVisible():Promise<boolean>

    loadUrl(url:string):Promise<void>

    

    //abiding by the contract

}

