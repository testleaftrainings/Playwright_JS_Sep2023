export enum Environment {
  STAGE = 'stage',
  BETA = 'beta',
}
