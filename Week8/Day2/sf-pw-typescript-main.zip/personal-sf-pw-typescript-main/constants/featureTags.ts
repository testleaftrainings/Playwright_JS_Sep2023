export enum FeatureTags {
    CREATE_ACCOUNT = "@create-account",
    DELETE_ACCOUNT = "@delete-account",
    EDIT_ACCOUNT = "@edit-account",
    LOGIN = "@login"
}