import { test, expect } from "@playwright/test";
import { LoginPage } from "../../page-objects/loginPage";
import { FrameWorkHelper } from "../../utils/frameworkHelper";
import { EnvConstants } from "../../constants/envConstants";
import { URLConstants } from "../../constants/urlConstants";
import { AppUrlConstants } from "../../constants/appConstants";
import { TestPriorityTags } from "../../constants/testPriorityTags";
import { FeatureTags } from "../../constants/featureTags";

test.describe(`${FeatureTags.LOGIN}`, async () => {
  test(`${TestPriorityTags.P0} TC001: verify with valid creds you are able to login`, async ({
    page,
  }) => {
    const appData = FrameWorkHelper.loadTestData(EnvConstants.STAGE);
    await page.goto(URLConstants.LOGIN_PAGE);
    const loginPage = new LoginPage(page);
    await loginPage.doLogin(appData.adminUserName, appData.adminPassword);
    await expect(page).toHaveURL(AppUrlConstants.INSTANCE_URL);

    //how to generate login storage state
    await page.context().storageState({ path: ".auth/credential.json" });
  });
});
