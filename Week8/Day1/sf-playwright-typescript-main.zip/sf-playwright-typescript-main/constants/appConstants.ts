//enum

export enum AppUrlConstants {
  INSTANCE_URL = "/lightning/setup/SetupOneHome/home",
  SETUP_HOMEPAGE_URL = "/lightning/page/home",
  SALES_HOMEPAGE_URL = "lightning/o/Account/list",
  ACCOUNT_HOMEPAGE_URL = "",
  NEW_ACCOUNT_PAGE_URL = "",
}

export enum ToggleStates {
  ON = "ON",
  OFF = "OFF",
}
