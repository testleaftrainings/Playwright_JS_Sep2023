import { Locator, Page, test, expect } from "@playwright/test";
import { BasePage, IPageAction1 } from "./basePage";
import { URLConstants } from "../constants/urlConstants";
import { LocateBy } from "./IPageActions";
import { SalesHomePage } from "./salesHomePage";
import { NavBarComponent } from "./ui-components/navbarComponent";
import { AppUrlConstants } from "../constants/appConstants";

export class SetupHomePage extends BasePage implements IPageAction1 {
  //verify the homepage is loaded
  //related to the context of the homepage
  async verifyThePageIsLoaded(): Promise<void> {
    await this.verifyTheLocatorIsVisible(
      this.pageAnchor,
      "verifying the home page is loaded based on anchor element"
    );
  }

  async loadThePage() {
    await test.step(`Loading the login page url`, async () => {
      await this.loadUrl(AppUrlConstants.SETUP_HOMEPAGE_URL);
    });
  }

  readonly navBarComponent: NavBarComponent;
  readonly pageAnchor: Locator;

  constructor(page: Page) {
    super(page);
    this.pageAnchor = this.page
      .locator(".tileTitle")
      .filter({ hasText: "Get Started with Einstein Bots" });
  }
}
