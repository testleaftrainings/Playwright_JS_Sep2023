import { createAccountTests, loggedInTests, nonLoggedInTests } from "./fixtures";
import {test} from "@playwright/test"

loggedInTests.describe(async()=>{

    loggedInTests('TC001 - CREATE ACCOUNT',async({page})=>{
       
    })
})

nonLoggedInTests.describe(async()=>{

    loggedInTests('TC002 - login validation',async({page})=>{
        //login tests

    })
})


createAccountTests.describe(async()=>{

    createAccountTests(`TC001 - creating new account`,async({createAccountPage})=>{
        createAccountPage.homePage.clickOnAppLauncherIcon()
    })
})