export class Human{ //parent class

    protected name:string


    constructor(name:string){
        this.name = name
    }

    walk(){
        console.log(`Human walking`)
    }
    run(){
        /**
         * 5 km per hour
         */
        console.log(`Human running with 5 km per hour`)
    }

    printInfo(){
        console.log(`Human name is ${this.name}`)
    }

    
}

type universe = "Marvel" | "DC"

//is super human a human? -> yes, its a human but with some different abilities
export class SuperHuman extends Human {

    belongsTo:universe
    
    constructor(name:string,universe:universe){
        //super keyword //construction of the parent class should be the first thing
        super(name)
        //child things can follow
        this.belongsTo = universe

    }

    run(){
        console.log(`Super human running with 50 km per hour`)

    }
    fly(){
        console.log(`Super human flying`)
    }

    
    printSuperUserInfo(){
        this.printInfo() //calling one method to print the basic human infor
        console.log(`${this.name} am from ${this.belongsTo}`)
    }
}
