import { Page,test,Locator,expect } from "@playwright/test";
import { IPageAction, LocateBy } from "./IPageActions";


//understanding of abstract class

/**
 * 
 * the abstract are not the complete class on its onw
 * i.e. these are incomplete class
 * 
 * these needs to be implemented fully in order to use in real word
 * 
 * Restriction -> you can not create an object of abstract class
 * 
 * 
 */
export abstract class BasePage{

    readonly page :Page

    constructor(page:Page){
        this.page = page
    }
    isLocatorVisible(): Promise<boolean> {
        throw new Error("Method not implemented.");
    }

    //main aim of wrapper method is to add extra features and similify the implementation
    async verifyTheUrlIsLoaded(expectedUrl:string,doExactMatch=true){
        if(doExactMatch){
            await expect(this.page).toHaveURL(expectedUrl,{timeout:15000}) //polling mechanism 
        }
        else{//custom assertions using retry mechanism/ polling mechanism
            expect.poll(()=>{
                const url = this.page.url()
                return url
    
            },{message:"",timeout:20000}).toContain(expectedUrl)
        }
    }

    abstract loadThePage():Promise<void>;

    abstract verifyThePageIsLoaded():Promise<void>;

    async loadUrl(url:string){
        await test.step(`Loading url ${url}`,async()=>{
            await this.page.goto(url)
        })
    }
    //making sure my 1 method handles both the conditions
    constructLocatorBasedOnSelector(selector:string){
        return this.page.locator(selector)
    }
    generateLocator(locateBy:LocateBy){
        return typeof(locateBy)==="string"?this.constructLocatorBasedOnSelector(locateBy):locateBy
    }

    async clickOn(locateBy:LocateBy,options?:{
        stepTitle?:string,
        thresholdTimout?:number|undefined,
    }){
        await test.step(`${options?.stepTitle} : Attempting to click on given locator`,async()=>{
            try{
                await this.generateLocator(locateBy).click({timeout:options?.thresholdTimout})
            }
            catch(err){
                console.log(`Error occured while trying to click on given locator : ${err}`)
            }

        })
    }

    async fillIn(locateBy:Locator|string,textToFill:string,options?:{
        stepTitle?:string,
        thresholdTimout?:number|undefined

    }){
        await test.step(`Trying to enter given text ${textToFill} in the locator`,async()=>{
            await this.generateLocator(locateBy).fill(textToFill)
        })
    }

    async verifyTheLocatorIsVisible(locateBy:LocateBy,assertionStatement:string){
        await test.step(`Verifying if the locator is visible`,async()=>{
            //expect should have an assertion statement
            await expect(this.generateLocator(locateBy),assertionStatement).toBeVisible()
        })
    }
}