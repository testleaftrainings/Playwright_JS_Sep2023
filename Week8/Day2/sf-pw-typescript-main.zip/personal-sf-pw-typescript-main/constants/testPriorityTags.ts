export enum TestPriorityTags {
    PO = "@P0",
    P1 = "@P1",
    p2 = "@P2"
}