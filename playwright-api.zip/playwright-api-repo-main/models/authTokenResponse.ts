export interface AuthTokenModelResponse {
  token: string;
}
