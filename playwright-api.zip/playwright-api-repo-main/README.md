# playwright-api-repo
Sample framework of how can we add only API cases into the repo
