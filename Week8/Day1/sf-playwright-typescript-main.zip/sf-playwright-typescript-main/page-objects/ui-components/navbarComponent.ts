import { Locator, Page } from "@playwright/test";
import { BasePage } from "../basePage";
import { AppLauncherComponent } from "./appLauncherComponents";
import { BaseComponent } from "./baseComponent";
import { TabNameConstants } from "../../constants/tabNameConstants";

export class NavBarComponent extends BaseComponent {
  appLauncherIcon: Locator;
  readonly appLauncherComponent: AppLauncherComponent;
  readonly tabNamesLocaotr: Locator;

  constructor(page: Page) {
    super(page);
    this.appLauncherComponent = new AppLauncherComponent(this.page);
    this.tabNamesLocaotr = this.page.locator("one-app-nav-bar-item-root");
  }

  async clickOnAppLauncherIcon() {
    await this.clickOn(this.appLauncherIcon, {
      stepTitle: "clicking on app launcher",
      thresholdTimout: 15000,
    });
  }

  async openTab(tabName: TabNameConstants) {
    const tabNameToClick = this.tabNamesLocaotr.filter({
      has: this.page.getByText(tabName),
    });
    await tabNameToClick.click();
  }
}
