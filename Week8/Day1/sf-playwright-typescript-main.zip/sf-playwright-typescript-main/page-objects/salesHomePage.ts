import { Locator, Page, test } from "@playwright/test";
import { BasePage, IPageAction1 } from "./basePage";
import { AppUrlConstants } from "../constants/appConstants";

export class SalesHomePage extends BasePage implements IPageAction1 {
  async loadThePage() {
    await test.step(`Loading the login page url`, async () => {
      await this.loadUrl(AppUrlConstants.SALES_HOMEPAGE_URL);
    });
  }

  async verifyThePageIsLoaded(): Promise<void> {
    throw new Error("Method not implemented.");
  }

  //locators

  readonly accountTabLocator: Locator;

  constructor(page: Page) {
    super(page);
    this.accountTabLocator = this.page.locator(
      "one-app-nav-bar-item-root a[title='Accounts']"
    );
  }

  //action
  async openAccountsTab() {
    await this.clickOn(this.accountTabLocator, {
      stepTitle: "Clicking on account tab from sales home page",
    });
    return this;
  }
}
