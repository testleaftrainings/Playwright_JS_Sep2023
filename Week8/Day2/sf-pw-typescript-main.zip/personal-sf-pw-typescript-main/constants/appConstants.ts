export enum AppConstants {
  INSTANCE_URL = '/lightning/setup/SetupOneHome/home',
  SETUP_HOMEPAGE_URL = '/lightning/setup/SetupOneHome/home',
  SALES_HOMEPAGE_URL = '/lightning/page/home',
  ACCOUNT_PAGE = '/lightning/o/Account/list?filterName=Recent',
  NEW_ACCOUNT_FORM_PAGE = '/lightning/o/Account/new',
  LOGIN_PAGE_URL = 'https://login.salesforce.com/',
}
