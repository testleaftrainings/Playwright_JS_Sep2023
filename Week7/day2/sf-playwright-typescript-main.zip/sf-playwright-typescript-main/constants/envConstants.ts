export enum EnvConstants{
    STAGE="stage",
    BETA="beta"
}