import { EnvConstants } from "../constants/envConstants"
import appData from "../test-data/appData.json"

export type AppData = {
    adminUserName:string,
    adminPassword:string
}

export class FrameWorkHelper{

    //to load the test data based on which environment

    static loadTestData(envName:EnvConstants):AppData{
        return appData[envName]
    }

    //loadTestData(EnvConstants.STAGE)
        /**
         * 
         * appData = {   
                        "stage":{
                            "adminUserName":"hari.radhakrishnan@qeagle.com",
                            "adminPassword":"Testleaf@123",

                        },
                        "beta":{
                            "adminUserName":"hari.radhakrishnan@qeagle.com",
                            "adminPassword":"Testleaf@123"
                        }
                    }
        
                                const envData   = loadTestData(stage)

                    {
                            "adminUserName":"hari.radhakrishnan@qeagle.com",
                            "adminPassword":"Testleaf@123"
                        },
        
         */
}